<template>
    
    <b-tooltip    
        v-show="!hide"
        :animated="true"
        :label="tltpText"
        :position="tltpPos"
        :type="tltpType" >

        <button
            ref="fabitem"
            class="fab-item button is-rounded is-paddingless"
            :class="[ size, type ]" 
            :style="itemStyle"
            :disabled="disabled" 
            @click="$parent.close()"
            v-on="inputListeners"
        >

            <font-awesome-icon
                :icon="icon"
                :spin="spin"
                :pulse="pulse"
                v-if="icon!==null" 
            />

            <slot name="default" v-else></slot>

        </button>

    </b-tooltip>

</template>

<script>
"use strict"
/* @ is an alias to /src */

export default {

    name: "fab-item",

    data () {

        return {
            radius: 0,
        }

    },

    mounted () {

       if ( !this.$parent.$data.isFloatingActionButton ) {

            this.$destroy()
            throw new Error('You should wrap <fab-item> on a <fab>')

        }

        this.radius = this.$refs.fabitem.offsetHeight

    },

    updated() {

        this.radius = this.$refs.fabitem.offsetHeight

    },

    props: {

        hide: {
            type: Boolean,
            default: false
        },

        disabled: {
            type: Boolean,
            default: false
        },

        size: {
            type: String,
            default: "is-normal",
        },

        type: {
            type: String,
            default: "is-dark",
        },

        gap: {
            type: String,
            default: "0.3rem"
        },

        icon: {
            type: String,
            default: "question"
        },

        spin: {
            type: Boolean,
            default: false
        },

        pulse: {
            type: Boolean,
            default: false
        },

        tltpText: {
            type: String,
            default: ""
        },

        tltpType: {
            type: String,
            default: "is-light"
        },

        tltpPos: {
            type: String,
            default: "is-left"
        }

    },

    computed: {

        itemStyle() {

            return this.radius !== 0 ? `width:${this.radius}px;height:${this.radius}px;margin:${this.gap} 0` : `margin:${this.gap} 0`

        },

        inputListeners() {

            var vm = this
            return Object.assign( {}, this.listeners, { input( event ) { vm.$emit( 'input', event.target.value ) } } )

        }

    }


}

</script>


<style scoped>

    .fab-item:hover {
        transform: rotate(-10deg)
    }

</style>
