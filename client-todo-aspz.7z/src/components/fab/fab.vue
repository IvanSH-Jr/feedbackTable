<template>
    <div
        ref="wrp"
        class="wrp"
        :style="wrpStyle"
    >

        <button
            ref="fab"
            class="fab button is-rounded is-paddingless"
            :class="[ size, type, animation ]"
            :style="fabStyle"
            :disabled="disabled"
            v-show="!hide"
            @click="shown=!shown"
            v-on="inputListeners"
        >
            <font-awesome-icon
                :icon="icon"
                :spin="spin"
                :pulse="pulse"
                v-if="icon!==null"
            ></font-awesome-icon>
            <slot name="default" v-else></slot>

        </button>

        <transition :name="slideDir" mode="out-in">
            <div
                ref="children"
                class="fab-children"
                v-if="shown"
            >
                <slot name="children"></slot>
            </div>
        </transition>

    </div>
</template>

<script>
"use strict"
/* @ is an alias to /src */

export default {

    name: "fab",

    data () {

        return {
            isFloatingActionButton: true,
            radius: 0,
            shown: false,
        }

    },

    mounted () {

        this.radius = this.$refs.fab.offsetHeight

    },

    updated() {

        this.radius = this.$refs.fab.offsetHeight

    },

    props: {

        hide: {
            type: Boolean,
            default: false
        },

        disabled: {
            type: Boolean,
            default: false
        },

        animated: {
            type: Boolean,
            default: true
        },

        size: {
            type: String,
            default: "is-large",
        },

        type: {
            type: String,
            default: "is-link",
        },

        position: {
            type: String,
            default: "bottom-right",
            validator( value ) {
                return value !== null ? [ "top-left", "top-right", "bottom-left", "bottom-right" ].indexOf( value ) !== -1 : 1
            }
        },

        offsetX: {
            type: String,
            default: "0"
        },

        offsetY: {
            type: String,
            default: "0"
        },

        gap: {
            type: String,
            default: "1rem"
        },

        icon: {
            type: String,
            default: "plus"
        },

        spin: {
            type: Boolean,
            default: false
        },

        pulse: {
            type: Boolean,
            default: false
        }

    },

    methods: {

        close() {

            this.shown = false

        }

    },

    computed: {

        wrpStyle() {

            let style = ""

            switch( this.position ) {

                case "top-left":
                    style = `top:${this.offsetY};left:${this.offsetX};flex-direction:column;margin:${this.gap};`
                    break;

                case "top-right":
                    style = `top:${this.offsetY};right:${this.offsetX};flex-direction:column;margin:${this.gap};`
                    break;

                case "bottom-left":
                    style = `bottom:${this.offsetY};left:${this.offsetX};flex-direction:column-reverse;margin:${this.gap};`
                    break;

                default:
                    style = `bottom:${this.offsetY};right:${this.offsetX};flex-direction:column-reverse;margin:${this.gap};`
                    break;

            }

            return style

        },

        fabStyle() {

            return this.radius !== 0 ? `width:${this.radius}px;height:${this.radius}px;` : ""

        },

        animation() {

            return ( this.shown && this.animated ) ? "shown" : "";

        },

        slideDir() {

            let style = ""

            switch( this.position ) {

                case "top-left":
                    style = "slide-up"
                    break;

                case "top-right":
                    style = "slide-up"
                    break;

                case "bottom-left":
                    style = "slide-down"
                    break;

                default:
                    style = "slide-down"
                    break;

            }

            return style

        },

        inputListeners() {
            var vm = this
            return Object.assign( {}, this.listeners, { input(event) { vm.$emit('input', event.target.value) } } )
        }

    },

}

</script>


<style scoped>

    .wrp {
        position: fixed;
        display: flex;
        flex-wrap: nowrap;
        align-items: center;
        height: auto;
    }

    .fab {
        transition: transform .3s ease;
    }

    .fab.shown {
        transform: rotate(-315deg)
    }

    .fab-children {
        margin: 5px 0;
        display: flex;
        flex-wrap: nowrap;
        flex-direction: column;
        align-items: center;
        height: auto;
        transition: all .3s ease;
    }

    .slide-up-enter, .slide-up-leave-to {
        transform: translateY(-7rem);
        opacity: 0;
    }
    .slide-down-enter, .slide-down-leave-to {
        transform: translateY(7rem);
        opacity: 0;
    }

</style>
